/**
 * Inland Empire - Psyche Panel
 * Main panel structure and tab switching
 */

import { extensionSettings, saveState } from '../systems/state.js';

// ═══════════════════════════════════════════════════════════════
// PANEL CREATION
// ═══════════════════════════════════════════════════════════════

export function createPsychePanel() {
    const panel = document.createElement('div');
    panel.id = 'inland-empire-panel';
    panel.className = 'inland-empire-panel';

    panel.innerHTML = `
        <div class="ie-panel-header">
            <div class="ie-panel-title">
                <i class="fa-solid fa-brain"></i>
                <span>Psyche</span>
            </div>
            <div class="ie-panel-controls">
                <button class="ie-btn ie-btn-close-panel" title="Close">
                    <i class="fa-solid fa-times"></i>
                </button>
            </div>
        </div>

        <div class="ie-tabs">
            <button class="ie-tab ie-tab-active" data-tab="skills" title="Skills">
                <i class="fa-solid fa-chart-bar"></i>
            </button>
            <button class="ie-tab" data-tab="cabinet" title="Thought Cabinet">
                <i class="fa-solid fa-box-archive"></i>
            </button>
            <button class="ie-tab" data-tab="status" title="Status">
                <i class="fa-solid fa-heart-pulse"></i>
            </button>
            <button class="ie-tab" data-tab="settings" title="Settings">
                <i class="fa-solid fa-gear"></i>
            </button>
            <button class="ie-tab" data-tab="profiles" title="Profiles">
                <i class="fa-solid fa-user-circle"></i>
            </button>
        </div>

        <div class="ie-panel-content">
            <!-- Skills Tab -->
            <div class="ie-tab-content ie-tab-content-active" data-tab-content="skills">
                <div class="ie-section ie-skills-overview">
                    <div class="ie-section-header"><span>Attributes</span></div>
                    <div class="ie-attributes-grid" id="ie-attributes-display"></div>
                </div>
                <div class="ie-section ie-voices-section">
                    <div class="ie-section-header">
                        <span>Inner Voices</span>
                        <button class="ie-btn ie-btn-sm ie-btn-clear-voices" title="Clear">
                            <i class="fa-solid fa-eraser"></i>
                        </button>
                    </div>
                    <div class="ie-voices-container" id="ie-voices-output">
                        <div class="ie-voices-empty">
                            <i class="fa-solid fa-comment-slash"></i>
                            <span>Waiting for something to happen...</span>
                        </div>
                    </div>
                </div>
                <div class="ie-section ie-manual-section">
                    <button class="ie-btn ie-btn-primary ie-btn-trigger" id="ie-manual-trigger">
                        <i class="fa-solid fa-bolt"></i>
                        <span>Consult Inner Voices</span>
                    </button>
                </div>
            </div>

            <!-- Cabinet Tab -->
            <div class="ie-tab-content" data-tab-content="cabinet" id="ie-cabinet-content"></div>

            <!-- Status Tab -->
            <div class="ie-tab-content" data-tab-content="status">
                <div class="ie-section">
                    <div class="ie-section-header"><span>Active Effects</span></div>
                    <div class="ie-active-effects-summary" id="ie-active-effects-summary">
                        <em>No active status effects</em>
                    </div>
                </div>
                <div class="ie-section">
                    <div class="ie-section-header"><span>Toggle Status Effects</span></div>
                    <div class="ie-status-grid" id="ie-status-grid"></div>
                </div>
                <div class="ie-section">
                    <div class="ie-section-header"><span>Ancient Voices</span></div>
                    <div class="ie-ancient-voices-info">
                        <div class="ie-ancient-voice-item">
                            <span class="ie-ancient-icon">🦎</span>
                            <span class="ie-ancient-name">Ancient Reptilian Brain</span>
                            <span class="ie-ancient-triggers">Triggers: Dying, Starving, Terrified, Aroused</span>
                        </div>
                        <div class="ie-ancient-voice-item">
                            <span class="ie-ancient-icon">❤️‍🔥</span>
                            <span class="ie-ancient-name">Limbic System</span>
                            <span class="ie-ancient-triggers">Triggers: Enraged, Grieving, Manic</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Settings Tab -->
            <div class="ie-tab-content" data-tab-content="settings">
                <div class="ie-section">
                    <div class="ie-section-header"><span>API Configuration</span></div>
                    <div class="ie-form-group">
                        <label>API Endpoint</label>
                        <input type="text" id="ie-api-endpoint" placeholder="https://api.example.com/v1" />
                    </div>
                    <div class="ie-form-group">
                        <label>API Key</label>
                        <input type="password" id="ie-api-key" placeholder="Your API key" />
                    </div>
                    <div class="ie-form-group">
                        <label>Model</label>
                        <input type="text" id="ie-model" placeholder="glm-4-plus" />
                    </div>
                    <div class="ie-form-row">
                        <div class="ie-form-group">
                            <label>Temperature</label>
                            <input type="number" id="ie-temperature" min="0" max="2" step="0.1" value="0.9" />
                        </div>
                        <div class="ie-form-group">
                            <label>Max Tokens</label>
                            <input type="number" id="ie-max-tokens" min="50" max="1000" value="300" />
                        </div>
                    </div>
                </div>

                <div class="ie-section">
                    <div class="ie-section-header"><span>Voice Behavior</span></div>
                    <div class="ie-form-row">
                        <div class="ie-form-group">
                            <label>Min Voices</label>
                            <input type="number" id="ie-min-voices" min="0" max="6" value="1" />
                        </div>
                        <div class="ie-form-group">
                            <label>Max Voices</label>
                            <input type="number" id="ie-max-voices" min="1" max="10" value="4" />
                        </div>
                    </div>
                    <div class="ie-form-group">
                        <label>Trigger Delay (ms)</label>
                        <input type="number" id="ie-trigger-delay" min="0" max="5000" step="100" value="1000" />
                    </div>
                    <div class="ie-form-group">
                        <label class="ie-checkbox">
                            <input type="checkbox" id="ie-show-dice-rolls" checked />
                            <span>Show dice roll results</span>
                        </label>
                    </div>
                    <div class="ie-form-group">
                        <label class="ie-checkbox">
                            <input type="checkbox" id="ie-show-failed-checks" checked />
                            <span>Show failed skill checks</span>
                        </label>
                    </div>
                    <div class="ie-form-group">
                        <label class="ie-checkbox">
                            <input type="checkbox" id="ie-auto-trigger" />
                            <span>Auto-trigger on AI messages</span>
                        </label>
                    </div>
                    <div class="ie-form-group">
                        <label class="ie-checkbox">
                            <input type="checkbox" id="ie-auto-detect-status" />
                            <span>Auto-detect status from narrative</span>
                        </label>
                    </div>
                </div>

                <div class="ie-section">
                    <div class="ie-section-header"><span>Intrusive Thoughts</span></div>
                    <div class="ie-form-group">
                        <label class="ie-checkbox">
                            <input type="checkbox" id="ie-intrusive-enabled" checked />
                            <span>Enable intrusive thoughts</span>
                        </label>
                    </div>
                    <div class="ie-form-group">
                        <label class="ie-checkbox">
                            <input type="checkbox" id="ie-intrusive-in-chat" checked />
                            <span>Show in chat (not just toasts)</span>
                        </label>
                    </div>
                    <div class="ie-form-group">
                        <label>Intrusive Chance (%)</label>
                        <input type="number" id="ie-intrusive-chance" min="0" max="100" value="15" />
                    </div>
                </div>

                <div class="ie-section">
                    <div class="ie-section-header"><span>Object Voices</span></div>
                    <div class="ie-form-group">
                        <label class="ie-checkbox">
                            <input type="checkbox" id="ie-object-voices-enabled" checked />
                            <span>Enable object voices</span>
                        </label>
                    </div>
                    <div class="ie-form-group">
                        <label>Object Voice Chance (%)</label>
                        <input type="number" id="ie-object-chance" min="0" max="100" value="40" />
                    </div>
                </div>

                <div class="ie-section">
                    <div class="ie-section-header"><span>Thought Cabinet</span></div>
                    <div class="ie-form-group">
                        <label class="ie-checkbox">
                            <input type="checkbox" id="ie-thought-discovery-enabled" checked />
                            <span>Enable thought discovery</span>
                        </label>
                    </div>
                    <div class="ie-form-group">
                        <label class="ie-checkbox">
                            <input type="checkbox" id="ie-auto-discover-thoughts" checked />
                            <span>Auto-discover thoughts</span>
                        </label>
                    </div>
                </div>

                <div class="ie-section">
                    <div class="ie-section-header"><span>POV & Character</span></div>
                    <div class="ie-form-group">
                        <label>Voice POV Style</label>
                        <select id="ie-pov-style">
                            <option value="second">Second Person (you/your)</option>
                            <option value="third">Third Person (name/they)</option>
                            <option value="first">First Person (I/me)</option>
                        </select>
                    </div>
                    <div class="ie-form-group ie-third-person-options">
                        <label>Character Name</label>
                        <input type="text" id="ie-character-name" placeholder="e.g. Harry" />
                    </div>
                    <div class="ie-form-group ie-third-person-options">
                        <label>Pronouns</label>
                        <select id="ie-character-pronouns">
                            <option value="they">They/Them</option>
                            <option value="he">He/Him</option>
                            <option value="she">She/Her</option>
                            <option value="it">It/Its</option>
                        </select>
                    </div>
                    <div class="ie-form-group">
                        <label>Character Context</label>
                        <textarea id="ie-character-context" rows="3" placeholder="Who are you? What's your situation?"></textarea>
                    </div>
                    <button class="ie-btn ie-btn-primary ie-btn-save-settings" style="width: 100%; margin-top: 10px;">
                        <i class="fa-solid fa-save"></i>
                        <span>Save Settings</span>
                    </button>
                    <button class="ie-btn ie-btn-reset-fab" style="width: 100%; margin-top: 8px;">
                        <i class="fa-solid fa-arrows-to-dot"></i>
                        <span>Reset Icon Position</span>
                    </button>
                </div>
            </div>

            <!-- Profiles Tab -->
            <div class="ie-tab-content" data-tab-content="profiles">
                <div class="ie-section">
                    <div class="ie-section-header"><span>Persona Profiles</span></div>
                    <div class="ie-profiles-list" id="ie-profiles-list"></div>
                </div>
                <div class="ie-section">
                    <div class="ie-section-header"><span>Save Current as Profile</span></div>
                    <div class="ie-form-group">
                        <label>Profile Name</label>
                        <input type="text" id="ie-new-profile-name" placeholder="e.g. Harry Du Bois" />
                    </div>
                    <button class="ie-btn ie-btn-primary" id="ie-save-profile-btn" style="width: 100%;">
                        <i class="fa-solid fa-save"></i>
                        <span>Save Profile</span>
                    </button>
                </div>
                <div class="ie-section">
                    <div class="ie-section-header"><span>Build Editor</span></div>
                    <div class="ie-build-intro">
                        <div class="ie-points-remaining">Points: <span id="ie-points-remaining">12</span> / 12</div>
                    </div>
                    <div class="ie-attributes-editor" id="ie-attributes-editor"></div>
                    <button class="ie-btn ie-btn-primary ie-btn-apply-build" style="width: 100%; margin-top: 10px;">
                        <i class="fa-solid fa-check"></i>
                        <span>Apply Build</span>
                    </button>
                </div>
            </div>
        </div>
    `;

    return panel;
}

// ═══════════════════════════════════════════════════════════════
// FAB CREATION
// ═══════════════════════════════════════════════════════════════

export function createToggleFAB(getContext) {
    const fab = document.createElement('div');
    fab.id = 'inland-empire-fab';
    fab.className = 'ie-fab';
    fab.title = 'Toggle Psyche Panel';
    fab.innerHTML = '<i class="fa-solid fa-brain"></i>';
    fab.style.display = 'flex';
    fab.style.top = `${extensionSettings.fabPositionTop ?? 140}px`;
    fab.style.left = `${extensionSettings.fabPositionLeft ?? 10}px`;

    // Dragging state
    let isDragging = false;
    let dragStartX, dragStartY, fabStartX, fabStartY;
    let hasMoved = false;

    function startDrag(e) {
        isDragging = true;
        hasMoved = false;
        const touch = e.touches ? e.touches[0] : e;
        dragStartX = touch.clientX;
        dragStartY = touch.clientY;
        fabStartX = fab.offsetLeft;
        fabStartY = fab.offsetTop;
        fab.style.transition = 'none';
        document.addEventListener('mousemove', doDrag);
        document.addEventListener('touchmove', doDrag, { passive: false });
        document.addEventListener('mouseup', endDrag);
        document.addEventListener('touchend', endDrag);
    }

    function doDrag(e) {
        if (!isDragging) return;
        e.preventDefault();
        const touch = e.touches ? e.touches[0] : e;
        const deltaX = touch.clientX - dragStartX;
        const deltaY = touch.clientY - dragStartY;
        if (Math.abs(deltaX) > 5 || Math.abs(deltaY) > 5) hasMoved = true;
        fab.style.left = `${Math.max(0, Math.min(window.innerWidth - fab.offsetWidth, fabStartX + deltaX))}px`;
        fab.style.top = `${Math.max(0, Math.min(window.innerHeight - fab.offsetHeight, fabStartY + deltaY))}px`;
    }

    function endDrag() {
        if (!isDragging) return;
        isDragging = false;
        fab.style.transition = 'all 0.3s ease';
        document.removeEventListener('mousemove', doDrag);
        document.removeEventListener('touchmove', doDrag);
        document.removeEventListener('mouseup', endDrag);
        document.removeEventListener('touchend', endDrag);

        if (hasMoved) {
            fab.dataset.justDragged = 'true';
            extensionSettings.fabPositionTop = fab.offsetTop;
            extensionSettings.fabPositionLeft = fab.offsetLeft;
            if (getContext) saveState(getContext());
        }
    }

    fab.addEventListener('mousedown', startDrag);
    fab.addEventListener('touchstart', startDrag, { passive: false });

    return fab;
}

// ═══════════════════════════════════════════════════════════════
// PANEL CONTROLS
// ═══════════════════════════════════════════════════════════════

export function togglePanel() {
    const panel = document.getElementById('inland-empire-panel');
    const fab = document.getElementById('inland-empire-fab');

    if (!panel) return;

    const isOpen = panel.classList.contains('ie-panel-open');

    if (isOpen) {
        panel.classList.remove('ie-panel-open');
        fab?.classList.remove('ie-fab-active');
    } else {
        panel.classList.add('ie-panel-open');
        fab?.classList.add('ie-fab-active');
    }
}

export function switchTab(tabName, callbacks = {}) {
    document.querySelectorAll('.ie-tab').forEach(tab =>
        tab.classList.toggle('ie-tab-active', tab.dataset.tab === tabName)
    );

    document.querySelectorAll('.ie-tab-content').forEach(content =>
        content.classList.toggle('ie-tab-content-active', content.dataset.tabContent === tabName)
    );

    // Tab-specific callbacks
    if (tabName === 'profiles' && callbacks.onProfiles) {
        callbacks.onProfiles();
    }
    if (tabName === 'settings' && callbacks.onSettings) {
        callbacks.onSettings();
    }
    if (tabName === 'status' && callbacks.onStatus) {
        callbacks.onStatus();
    }
    if (tabName === 'cabinet' && callbacks.onCabinet) {
        callbacks.onCabinet();
    }
}
